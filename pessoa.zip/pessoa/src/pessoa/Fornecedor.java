/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import javax.swing.JOptionPane;

/**
 *
 * @author Jhenifer
 */
public class Fornecedor extends Pessoa {
    private float valorCompra;
    Fornecedor(){}
    Fornecedor(String n, String f, float vc){
        super (n,f);
        valorCompra = vc;
    }
    public float getValorCompra(){
        return valorCompra;
    }
    public void setValorCompra( float valorCompra){
        this.valorCompra = valorCompra;
    }
    public void print(){
        super.print();
        JOptionPane.showMessageDialog(null, "\n Valor da compra:" + valorCompra); 
}
    public void CalcImpostos (float imposto){
        valorCompra += valorCompra * imposto/100;
    }

    void calculaImpostos(float f) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}