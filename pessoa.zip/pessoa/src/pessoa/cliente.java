/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import javax.swing.JOptionPane;

/**
 *
 * @author Jhenifer
 */
public class cliente  extends Pessoa{
  private float valorDivida;
  cliente(){}
  cliente(String n, String f, float vd){
      super (n,f);
      valorDivida = vd;
  }
  public float getValorDivida(){
      return valorDivida;
  }
  public void setValorDivida (float valorDivida){
      this.valorDivida = valorDivida;
  }
  public void print (){
      super.print();
      JOptionPane.showMessageDialog(null,"\nValor dadivida:" + valorDivida);
  }
  public float calculaJuros (float tx){
      return valorDivida*tx/100;
  }
}
