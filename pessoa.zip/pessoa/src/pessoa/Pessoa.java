/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import javax.swing.JOptionPane;

        public class Pessoa{
            
            private String nome;
            private String fone;
            Pessoa() {
        }
            Pessoa(String n, String f){
                nome = n;
                fone = f;
            }

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public String getFone() {
            return fone;
        }

        public void setFone(String fone) {
            this.fone = fone;
        }
            public void print(){
                JOptionPane.showMessageDialog(null, "Dados \nNome:" + nome + "\nTel:" + fone);
            }
    }  
